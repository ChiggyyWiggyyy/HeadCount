import os
import cv2
import torch
import numpy as np

# Load the YOLOv5 model from PyTorch Hub
model = torch.hub.load('ultralytics/yolov5', 'custom', path='/Users/iamyashtyagi/Desktop/Interviews/Crowd Detection/yolov5s.pt', force_reload=True)

# Define paths
images_dir = './data/images'
output_dir = './data/output'
os.makedirs(output_dir, exist_ok=True)

# Proportional resize with padding (letterbox)
def letterbox_image(image, target_size):
    height, width = image.shape[:2]
    scale = min(target_size[0] / width, target_size[1] / height)
    new_width, new_height = int(width * scale), int(height * scale)
    resized_image = cv2.resize(image, (new_width, new_height))
    padded_image = np.full((target_size[1], target_size[0], 3), 128, dtype=np.uint8)
    padded_image[(target_size[1] - new_height) // 2 : (target_size[1] - new_height) // 2 + new_height, (target_size[0] - new_width) // 2 : (target_size[0] - new_width) // 2 + new_width] = resized_image
    return padded_image, (target_size[0] - new_width) // 2, (target_size[1] - new_height) // 2, scale

# Load and process images, then run inference
image_files = [f for f in os.listdir(images_dir) if f.endswith('.jpg')]
for image_file in image_files:
    image_path = os.path.join(images_dir, image_file)
    image = cv2.imread(image_path)

    # Resize and pad image
    img_resized, offset_x, offset_y, scale = letterbox_image(image, (640, 640))

    # Run inference
    results = model([img_resized])

    # Process results
    head_count = 0
    for det in results.xyxy[0]:
        if det[-1] == 0:  # Assuming '0' is the class index for 'person' (head)
            head_count += 1
            x1, y1, x2, y2 = int((det[0] - offset_x) / scale), int((det[1] - offset_y) / scale), int((det[2] - offset_x) / scale), int((det[3] - offset_y) / scale)
            cv2.rectangle(image, (x1, y1), (x2, y2), (0, 255, 0), 2)

    # Annotate and save the output image
    cv2.putText(image, f'Heads: {head_count}', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)
    output_path = os.path.join(output_dir, image_file)
    cv2.imwrite(output_path, image)
    print(f"Processed {image_file}: {head_count} heads detected and saved to {output_path}")
